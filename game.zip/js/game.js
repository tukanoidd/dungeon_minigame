var gameState = { gravity: 15, direction: 'right', isJumping: false };

function preload() {
    this.load.image('dungeonTiles', 'assets/tileset.png');
    this.load.tilemapTiledJSON('map', 'assets/map.json');
    this.load.spritesheet('player', 'assets/player_spritesheet.png', {
        frameWidth: 50,
        frameHeight: 37
    });
}

function create() {
    gameState.cursors = this.input.keyboard.createCursorKeys();
    gameState.speed = 3;
    gameState.runFPS = 15;
    gameState.jumpFPS = 10;
    gameState.idleFPS = 5;

    gameState.map = this.add.tilemap('map');
    gameState.dungeonTileset = gameState.map.addTilesetImage('dungeon', 'dungeonTiles');

    gameState.backgroundLayer = gameState.map.createStaticLayer('Background', gameState.dungeonTileset);
    gameState.mapLayer = gameState.map.createStaticLayer('Map', gameState.dungeonTileset);
    gameState.miscLayer = gameState.map.createStaticLayer('Misc', gameState.dungeonTileset);

    gameState.mapLayer.setCollisionByExclusion([-1]);

    // set the boundaries of our game world
    this.physics.world.bounds.width = gameState.mapLayer.width;
    this.physics.world.bounds.height = gameState.mapLayer.height;

    gameState.player = this.physics.add.sprite(73, 398, 'player', 0);
    gameState.player.setCollideWorldBounds(true);

    addPlayerAnims(this);

    this.cameras.main.zoom = 2;
    this.cameras.main.setBounds(0, 0, gameState.map.widthInPixels, gameState.map.heightInPixels);
    this.cameras.main.startFollow(gameState.player);

    this.physics.add.collider(gameState.mapLayer, gameState.player);
    console.log(this.physics);
}

function addPlayerAnims(game) {
    game.anims.create({
        key: 'player_idle',
        frames: game.anims.generateFrameNumbers('player', {start: 0, end: 3}),
        frameRate: gameState.idleFPS,
        repeat: -1
    });

    game.anims.create({
        key: 'player_run',
        frames: game.anims.generateFrameNumbers('player', {start: 8, end: 13}),
        frameRate: gameState.runFPS,
        repeat: -1
    });

    game.anims.create({
        key: 'player_duck',
        frames: game.anims.generateFrameNumbers('player', {start: 4, end: 7}),
        frameRate: gameState.idleFPS,
        repeat: -1
    });

    game.anims.create({
        key: 'player_jump',
        frames: game.anims.generateFrameNumbers('player', {start: 16, end: 23}),
        frameRate: gameState.jumpFPS,
        repeat: 0
    });
}

function update() {
    var keys = this.input.keyboard.addKeys('W,A,S,D,R');

    if (keys.R.isDown) reset();

    if (keys.W.isDown || gameState.cursors.up.isDown) {
        if (!gameState.isJumping) {
            gameState.isJumping = true;
            gameState.player.anims.play('player_jump', true).once('animationcomplete', () => {
                gameState.player.anims.play('player_idle');
                gameState.isJumping = false;
            });
        }
    } else if (keys.A.isDown || gameState.cursors.left.isDown) {
        if (gameState.direction !== 'left') {
            gameState.direction = 'left';
            gameState.player.scaleX = -1;
        }

        if (!gameState.isJumping) {
            gameState.player.anims.play('player_run', true);
        }
        gameState.player.x -= gameState.speed;
    } else if (keys.S.isDown || gameState.cursors.down.isDown) {
        if (!gameState.isJumping) {
            gameState.player.anims.play('player_duck', true);
        }
    } else if (keys.D.isDown || gameState.cursors.right.isDown) {
        if (gameState.direction !== 'right') {
            gameState.direction = 'right';
            gameState.player.scaleX = 1;
        }

        if (!gameState.isJumping) {
            gameState.player.anims.play('player_run', true);
        }
        gameState.player.x += gameState.speed;
    } else {
        if (!gameState.isJumping) {
            gameState.player.anims.play('player_idle', true);
        }
    }
}

function reset() {

}

const config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    backgroundColor: "#f",
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: gameState.gravity },
            debug: true
        }
    },
    scene: {
        preload,
        create,
        update
    }
};

var game = new Phaser.Game(config);
